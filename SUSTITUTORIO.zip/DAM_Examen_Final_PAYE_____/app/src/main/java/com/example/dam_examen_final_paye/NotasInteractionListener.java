package com.example.dam_examen_final_paye;

public interface NotasInteractionListener {
    void editNotaClick(Nota nota);
    void eliminaNotaClick (Nota nota);
    void favoritaNotaClick (Nota nota);
}
